package com.example.livraria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViagensApplicationTests {

	@Test
	void contextLoads() {
	}

}
