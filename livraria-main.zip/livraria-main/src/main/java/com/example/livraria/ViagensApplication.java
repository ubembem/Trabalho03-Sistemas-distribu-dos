package com.example.livraria;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.livraria.dao.PassageiroRepository;
import com.example.livraria.dao.ViagemRepository;
import com.example.livraria.model.Passageiro;
import com.example.livraria.model.Viagem;

@SpringBootApplication
public class ViagensApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(ViagensApplication.class, args);
	}

	@Autowired
    PassageiroRepository passageiroRepository;

	@Autowired
	ViagemRepository viagemRepository;

	@Override
	public void run(String... args) throws Exception {

		List<Passageiro> Passageiros = new ArrayList<>();

		Passageiros.add(PassageiroRepository.save(new Passageiro(null, "Adriano Almeida", new Date(2001-01-01))));
		Passageiros.add(PassageiroRepository.save(new Passageiro(null, "Paulo Silveira", new Date(2001-9-9))));

		Viagem viagem = new Viagem(null,
				Passageiros, "Porto de galinhas",
				"Conheça Porto de galinhas",
				new Date(), new Date());

		viagemRepository.save(viagem);

		Passageiros = new ArrayList<>();

		Passageiros.add(PassageiroRepository.save(new Passageiro(null, "Vinicius Baggio Fuentes", new Date(2000-01-01))));

		viagemRepository.save(new Viagem(null,
				Passageiros, "Palmas - Tocantins",
				"Conheça a capital do Tocantins e suas belezas naturais", new Date(2024-12-12),
				new Date(2024-12-20)));

	}

}
