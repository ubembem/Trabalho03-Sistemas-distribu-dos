package com.example.livraria.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.livraria.dao.ViagemRepository;
import com.example.livraria.model.Viagem;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/viagens")
public class ViagemController {

    @Autowired
    ViagemRepository viagemRepository;

    @GetMapping("/viagem")
    List<Viagem> all() {
        return viagemRepository.findAll();
    }

    @GetMapping("/viagem/{id}")
    Optional<Viagem> getById(@PathVariable Integer id) {
        return viagemRepository.findById(id);
    }

    @PostMapping("/viagem")
    Viagem createNew(@Valid @RequestBody Viagem novoViagem) {
        novoViagem.setId(null);
        return viagemRepository.save(novoViagem);
    }

    @DeleteMapping("/viagem/{id}")
    void delete(@PathVariable Integer id) {
        viagemRepository.deleteById(id);
    }

    @PutMapping("/viagem/{id}")
    Viagem updateOrCreate(@RequestBody Viagem novoViagem, @PathVariable Integer id) {

        return viagemRepository.findById(id)
                .map(viagem -> {
                    viagem.setPassageiros(novoViagem.getPassageiros());
                    viagem.setDestino(novoViagem.getDestino());
                    viagem.setDescricao(novoViagem.getDescricao());
                    viagem.setDataDeInicio(novoViagem.getDataDeInicio());
                    viagem.setDataDeFim(novoViagem.getDataDeFim());
                    return viagemRepository.save(viagem);
                })
                .orElseGet(() -> {
                    novoViagem.setId(id);
                    return viagemRepository.save(novoViagem);
                });
    }
}
