package com.example.livraria.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.livraria.model.Viagem;

@Repository
public interface ViagemRepository extends JpaRepository<Viagem, Integer> {
    
}
