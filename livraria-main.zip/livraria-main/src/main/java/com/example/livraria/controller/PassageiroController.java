package com.example.livraria.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.livraria.dao.PassageiroRepository;
import com.example.livraria.model.Passageiro;

@RestController
@RequestMapping("/viagens")
public class PassageiroController {

    @Autowired
    PassageiroRepository passageiroRepository;

    @GetMapping("/passageiro")
    List<Passageiro> listarPassageiros() {
        return passageiroRepository.findAll();
    }

    @GetMapping("/passageiro/{id}")
    Optional<Passageiro> getById(@PathVariable Integer id) {
        return passageiroRepository.findById(id);
    }

    @PostMapping("/passageiro")
    Passageiro createNew(@RequestBody Passageiro novoPassageiro) {
        novoPassageiro.setId(null);
        return passageiroRepository.save(novoPassageiro);
    }

    @DeleteMapping("/passageiro/{id}")
    void delete(@PathVariable Integer id) {
        passageiroRepository.deleteById(id);
    }

    @PutMapping("/passageiro/{id}")
    Passageiro updateOrCreate(@RequestBody Passageiro novoPassageiro, @PathVariable Integer id) {

        return passageiroRepository.findById(id)
                .map(passageiro -> {
                    passageiro.setNome(novoPassageiro.getNome());
                    passageiro.setDataNascimento(novoPassageiro.getDataNascimento());
                    return passageiroRepository.save(passageiro);
                })
                .orElseGet(() -> {
                    novoPassageiro.setId(id);
                    return passageiroRepository.save(novoPassageiro);
                });
    }

}
